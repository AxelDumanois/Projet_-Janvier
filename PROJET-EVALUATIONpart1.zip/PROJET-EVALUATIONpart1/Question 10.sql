

SELECT type_terre.nom, COUNT(fktype_terre) FROM terrain
INNER JOIN type_terre
ON terrain.fktype_terre = type_terre.idtype_terre
GROUP BY fktype_terre
ORDER BY COUNT(fktype_terre) DESC;