
DELIMITER |

DROP FUNCTION IF EXISTS rajout_q3|

CREATE FUNCTION rajout_q3()
RETURNS INT(20)
deterministic

BEGIN

UPDATE culture 
	SET fkterrain = fkterrain + 25 
    WHERE fkterrain < 26;
    return 1;

END|

DELIMITER ;

SELECT rajout_q3();

SELECT * FROM culture;

#DESCRIBE culture;


