# Rendement de viande par élevage et par nom d'animal


SELECT idelevage, nom, quantite / elevage.capacite AS rendement FROM animal
INNER JOIN elevage
ON animal.idanimal = elevage.fkanimal
INNER JOIN productionviande
ON productionviande.fkelevage = elevage.idelevage
GROUP BY elevage.idelevage;

