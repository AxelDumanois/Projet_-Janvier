

SELECT idculture, produit.nom, qtx
FROM traitement
INNER JOIN culture ON traitement.fkculture = culture.idculture
INNER JOIN produit ON traitement.fkproduit = produit.idproduit
GROUP BY (idculture)