
# produit.idproduit ; traitement.qtx ; culture.idculture

SELECT culture.idculture, traitement.qtx, produit.idproduit
FROM culture
INNER JOIN traitement
ON idculture = fkculture
INNER JOIN produit 
ON idproduit = fkproduit
GROUP BY idculture, idproduit;




