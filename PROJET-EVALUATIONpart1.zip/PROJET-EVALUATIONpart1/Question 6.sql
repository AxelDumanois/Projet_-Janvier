

DELIMITER |

DROP FUNCTION IF EXISTS qte_plante |

CREATE FUNCTION qte_plante(Elevage INT, Plante VARCHAR(45)) 
RETURNS INT
deterministic
BEGIN
	DECLARE qte_select INT DEFAULT 0;
	SELECT alimentation.qtx INTO qte_select FROM plante
    
	INNER JOIN alimentation 
    ON  plante.idplante = alimentation.fkplante 
	INNER JOIN animal 
    ON animal.idanimal = alimentation.fkanimal
	INNER JOIN elevage 
    ON elevage.fkanimal = animal.idanimal
    
	WHERE elevage.idelevage = Elevage AND plante.nom = Plante;
	RETURN qte_select;
END |

DELIMITER ;

SELECT qte_plante('6','Millet');
