

SELECT employe.idemploye, employe.fkposte, culture.idculture 
FROM employe, culture
ORDER BY 
(CASE 
	WHEN employe.fkposte = '11'
    THEN culture.idculture = '112' OR '232'
END);





