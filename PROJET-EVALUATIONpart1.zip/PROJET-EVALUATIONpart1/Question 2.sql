
USE laferme;


SELECT COUNT(DISTINCT fkplante) FROM culture;

