
USE laferme;

CREATE TABLE precipitations (
id_precipitations INT(15) PRIMARY KEY,
fkterrain INT(10) unsigned NOT NULL,
saison VARCHAR(25) NOT NULL,
quantite FLOAT(10) NOT NULL,
CONSTRAINT fk_idterrain_pre FOREIGN KEY (fkterrain) REFERENCES terrain(idterrain)
);

CREATE TABLE temperature (
id_temperature INT(15) PRIMARY KEY,
fkterrain int(10) unsigned NOT NULL,
periode DATE, # On mettra le dernier jour du mois pour chaque mois
tp_max DECIMAL(5,2) NOT NULL,
tp_moy DECIMAL(5,2) NOT NULL,
tp_min DECIMAL(5,2) NOT NULL,
CONSTRAINT fk_idterrain_tem FOREIGN KEY (fkterrain) REFERENCES terrain (idterrain)
);


ALTER TABLE culture ADD FOREIGN KEY (fkresponsable) REFERENCES employe(idemploye);

describe precipitations;
describe temperature;




