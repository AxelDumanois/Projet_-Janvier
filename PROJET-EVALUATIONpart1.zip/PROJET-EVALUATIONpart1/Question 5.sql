# Liste qté de plantes consommées

SELECT alimentation.qtx, plante.nom, animal.nom, elevage.idelevage, alimentation.annee FROM plante
INNER JOIN alimentation
ON plante.idplante = fkplante
INNER JOIN animal
ON animal.idanimal = fkanimal
INNER JOIN elevage
ON animal.idanimal = elevage.fkanimal;

